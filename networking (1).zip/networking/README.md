# Networking

1. Deploy VPC
    - VPC module
    - Trusted SG
    - Peering if needed
2. Deploy NAT
    - NAT SG
    - NAT instances
    - Route table routes (adds a route to nat instance eni)
    - Deploy Ansible
4. Deploy Transit Gateway if needed
    - If you need to add a new VPC attachment in an existing Transit Gateway add a new block inside configs object like the following:
    ```
    inputs = {
        ...
        config = {
            "prd" = {
            ...
            },
            "stg" = {
            ..
            },
            "new-vpc-attachment" = {
                vpc_id          = "vpc-123"
                subnet_ids      = ["subnet-1", "subnet-2", "subnet-3", "subnet-4", "subnet-5"] # private-subnets
                route_table_ids = ["rt-1", "rt-2", "rt-3", "rt-4", "rt-5"]
                route_to_cidrs  = ["172.16.0.0/16"]
                static_routes   = []
            }
        }
    }
    ```
